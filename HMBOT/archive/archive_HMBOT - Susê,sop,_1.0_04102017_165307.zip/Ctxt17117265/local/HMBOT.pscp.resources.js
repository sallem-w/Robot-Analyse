﻿// Contextor Studio
// Auto-generated declaration file : do not modify !

